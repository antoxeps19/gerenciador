// App principal do Gerenciador de Tarefas
