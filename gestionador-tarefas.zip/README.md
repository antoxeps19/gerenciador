# Gerenciador de Tarefas Refatorado
