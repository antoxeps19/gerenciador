// Hook useAnimations
