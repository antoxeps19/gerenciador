// Estilos centralizados
