// Constantes globais
